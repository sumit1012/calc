module calc {
	requires java.desktop;
}